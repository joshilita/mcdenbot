const Discord = require('discord.js');
const fs = require('fs');
module.exports = {
  name: "sc",
  catergory: "admin",
  run: async (bot, message, args) => {
    if(!message.member.roles.cache.find(r => r.name === "Gen Access")) {
    message.channel.send(`${message.author}, You do not have the Gen Access Role!`)
    return;
}
    function getRandomLine(filename){
   var data = fs.readFileSync(filename, "utf8");
   var lines = data.split('\n');
   return lines[Math.floor(Math.random()*lines.length)];
}
var the_random_line_text = getRandomLine('code.txt');
const embed = new Discord.MessageEmbed()
.setTitle("Amazon SC Generated")
.setAuthor("Crackhead Bot", "https://images.squarespace-cdn.com/content/v1/5400daaee4b0551d6ace400a/1409418388242-WA7J8YXWUKOMKVVSXZDH/ke17ZwdGBToddI8pDm48kAH1C_phgBjBybBU6o8ICoBZw-zPPgdn4jUwVcJE1ZvWQUxwkmyExglNqGp0IvTJZamWLI2zvYWH8K3-s_4yszcp2ryTI0HqTOaaUohrI8PI59XFahmVwbKlYGlWva9ir0LvDU24VPfohFkRwxRP2gI/amazon.png","https://images.squarespace-cdn.com/content/v1/5400daaee4b0551d6ace400a/1409418388242-WA7J8YXWUKOMKVVSXZDH/ke17ZwdGBToddI8pDm48kAH1C_phgBjBybBU6o8ICoBZw-zPPgdn4jUwVcJE1ZvWQUxwkmyExglNqGp0IvTJZamWLI2zvYWH8K3-s_4yszcp2ryTI0HqTOaaUohrI8PI59XFahmVwbKlYGlWva9ir0LvDU24VPfohFkRwxRP2gI/amazon.png")
.setColor(0x00AE86)
.setDescription("Check your DMs. Your SC is generated.")
.setFooter("Made by JoshuaCoding#7204, ")
.setThumbnail("https://images.squarespace-cdn.com/content/v1/5400daaee4b0551d6ace400a/1409418388242-WA7J8YXWUKOMKVVSXZDH/ke17ZwdGBToddI8pDm48kAH1C_phgBjBybBU6o8ICoBZw-zPPgdn4jUwVcJE1ZvWQUxwkmyExglNqGp0IvTJZamWLI2zvYWH8K3-s_4yszcp2ryTI0HqTOaaUohrI8PI59XFahmVwbKlYGlWva9ir0LvDU24VPfohFkRwxRP2gI/amazon.png")
.setTimestamp()
message.channel.send({embed})
message.author.send(`Generated: ${the_random_line_text}`)
  }
}