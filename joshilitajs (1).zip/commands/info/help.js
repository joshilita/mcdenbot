const Discord = require('discord.js')
module.exports = {
  name: "help",
  category: "info",
  run: async (bot, message, args) => {
      const embed = new Discord.MessageEmbed()
.setTitle("Help")
.setURL("https://yagami.xyz/post-1/")
.setAuthor("Crackhead Bot", "https://images.squarespace-cdn.com/content/v1/5400daaee4b0551d6ace400a/1409418388242-WA7J8YXWUKOMKVVSXZDH/ke17ZwdGBToddI8pDm48kAH1C_phgBjBybBU6o8ICoBZw-zPPgdn4jUwVcJE1ZvWQUxwkmyExglNqGp0IvTJZamWLI2zvYWH8K3-s_4yszcp2ryTI0HqTOaaUohrI8PI59XFahmVwbKlYGlWva9ir0LvDU24VPfohFkRwxRP2gI/amazon.png","https://images.squarespace-cdn.com/content/v1/5400daaee4b0551d6ace400a/1409418388242-WA7J8YXWUKOMKVVSXZDH/ke17ZwdGBToddI8pDm48kAH1C_phgBjBybBU6o8ICoBZw-zPPgdn4jUwVcJE1ZvWQUxwkmyExglNqGp0IvTJZamWLI2zvYWH8K3-s_4yszcp2ryTI0HqTOaaUohrI8PI59XFahmVwbKlYGlWva9ir0LvDU24VPfohFkRwxRP2gI/amazon.png")
.setColor(0x00AE86)
.setDescription("Gen Access & VIP")
.setFooter("Made by JoshuaCoding#7204, ")
.addFields(
		{ name: '-sc', value: 'Will generate an Amazon Store card just for you.' }
    )
.setThumbnail("https://images.squarespace-cdn.com/content/v1/5400daaee4b0551d6ace400a/1409418388242-WA7J8YXWUKOMKVVSXZDH/ke17ZwdGBToddI8pDm48kAH1C_phgBjBybBU6o8ICoBZw-zPPgdn4jUwVcJE1ZvWQUxwkmyExglNqGp0IvTJZamWLI2zvYWH8K3-s_4yszcp2ryTI0HqTOaaUohrI8PI59XFahmVwbKlYGlWva9ir0LvDU24VPfohFkRwxRP2gI/amazon.png")
.setTimestamp()
message.channel.send({embed})
  }
}